#!/usr/bin/env bash
set -e
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs build-essential
# Install MySQL
sudo apt-get install -y mysql-server
sudo systemctl start mysql
# Create database and user
mysql -u root <<SQL
CREATE DATABASE chatapp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'chatuser'@'localhost' IDENTIFIED BY 'Chat@1234';
GRANT ALL PRIVILEGES ON chatapp.* TO 'chatuser'@'localhost';
FLUSH PRIVILEGES;
SQL
# Import schema
mysql -u chatuser -pChat@1234 chatapp < migrations/init.sql
# Install server dependencies
cd server
npm install
echo "Setup complete."
