import 'package:flutter/material.dart';
class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  List<Map<String,String>> messages = [];
  String? selectedVoice;
  final TextEditingController ctrl = TextEditingController();
  void send() {
    if(ctrl.text.isEmpty||selectedVoice==null) return;
    setState(()=>messages.add({'text':ctrl.text,'voice':selectedVoice!}));
    ctrl.clear();
  }
  void pick() async {
    final v = await showDialog<String>(context: context, builder:(c)=>SimpleDialog(
      title: const Text('Pick Voice'), children:[
        SimpleDialogOption(onPressed:()=>Navigator.pop(c,'en-US-Chirp3'),child:const Text('English Chirp3')),
        SimpleDialogOption(onPressed:()=>Navigator.pop(c,'vi-VN-Chirp3-HD'),child:const Text('Tiếng Việt Chirp3 HD')),
      ],
    ));
    if(v!=null) setState(()=>selectedVoice=v);
  }
  @override Widget build(BuildContext c)=>Scaffold(
    body: Row(children:[
      NavigationRail(destinations:[
        const NavigationRailDestination(icon:Icon(Icons.person),label:Text('Alice')),
        const NavigationRailDestination(icon:Icon(Icons.person),label:Text('Bob')),
      ],selectedIndex:0,onDestinationSelected:(_)=>{},labelType:NavigationRailLabelType.all),
      const VerticalDivider(width:1),
      Expanded(child:Column(children:[
        Expanded(child:ListView.builder(
          padding:const EdgeInsets.all(8),itemCount:messages.length,
          itemBuilder:(ctx,i){
            final m=messages[i];
            return Align(
              alignment: Alignment.centerRight,
              child:Container(padding:const EdgeInsets.all(8),margin:const EdgeInsets.all(4),
                decoration:BoxDecoration(color:Colors.blue[100],borderRadius:BorderRadius.circular(8)),
                child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Text(m['text']!),
                  Text(m['voice']!,style:const TextStyle(fontSize:10,color:Colors.grey)),
                ]),
              ),
            );
          },
        )),
        Container(padding:const EdgeInsets.all(8),color:Colors.white,child:Row(children:[
          IconButton(icon:const Icon(Icons.record_voice_over),onPressed:pick),
          if(selectedVoice!=null) Text(selectedVoice!,style:const TextStyle(color:Colors.grey)),
          Expanded(child:TextField(controller:ctrl)),
          IconButton(icon:const Icon(Icons.send),onPressed:send),
        ])),
      ])),
    ]),
    bottomNavigationBar: const Padding(padding:EdgeInsets.all(8),
      child:Text('Dự án phi lợi nhuận, thực hiện bởi ChatGPT dựa trên ý tưởng Nguyen's',
      textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:Colors.grey))),
  );
}