import 'package:flutter/material.dart';
import 'ui/chat_screen.dart';
void main() => runApp(const ChatApp());
class ChatApp extends StatelessWidget {
  const ChatApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ChatApp', theme: ThemeData.light(),
      home: const ChatScreen(),
    );
  }
}
