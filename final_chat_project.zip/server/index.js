const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const pool = require('./db');
const bcrypt = require('bcrypt');
require('dotenv').config();
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.json());
app.use(require('cors')());
app.post('/api/register', async (req, res) => {
  const { username, password, display_name } = req.body;
  const hash = await bcrypt.hash(password, 10);
  await pool.query('INSERT INTO users (username,password_hash,display_name) VALUES (?,?,?)', [username, hash, display_name]);
  res.sendStatus(201);
});
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
  const user = rows[0];
  if (!user) return res.sendStatus(404);
  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.sendStatus(401);
  res.json({ id: user.id, display_name: user.display_name });
});
app.get('/api/voices', async (req, res) => {
  const [rows] = await pool.query('SELECT locale, voice FROM voices');
  res.json(rows);
});
app.post('/api/voices', async (req, res) => {
  const { locale, voice } = req.body;
  await pool.query('INSERT INTO voices (locale,voice) VALUES (?,?)', [locale, voice]);
  res.sendStatus(201);
});
io.on('connection', (socket) => {
  socket.on('send-message', (msg) => io.emit('receive-message', msg));
});
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
