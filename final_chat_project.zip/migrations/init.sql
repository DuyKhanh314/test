-- Create tables
CREATE TABLE voices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  locale VARCHAR(10) NOT NULL,
  voice VARCHAR(50) NOT NULL
);
INSERT INTO voices (locale, voice) VALUES
('en-US', 'en-US-Chirp3'),
('vi-VN', 'vi-VN-Chirp3-HD');
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(30) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(50) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO users (username, password_hash, display_name) VALUES
('admin', SHA2('admin123',256), 'Administrator');
